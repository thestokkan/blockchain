import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class BlockChain {
    List<Block> blocks = new ArrayList<>();

    public BlockChain() {
        Block genesis = new Block(2);
        blocks.add(genesis);
    }

    @Override
    public String toString() {
        return "BlockChain{" +
                "blocks=" + blocks +
                '}';
    }

    public Block getLatestBlock() {
        return blocks.get(blocks.size() - 1);
    }

    public void addBlock(Block nextBlock) {
        nextBlock.prevHash = this.getLatestBlock().hash;
        nextBlock.hash = nextBlock.calculateHash();
        this.blocks.add(nextBlock);
    }

    /**
     * The balance for an address is total amount of transactions where address is receiver (to) minus
     * the total amount where address is sender (from)
     *
     * @param address the address to calculate balance for
     * @return the current balance
     */
    public int calculateBalance(String address) {
        int sumOut = this.blocks.stream()
                .flatMap(b -> b.transactionList.stream())
                .filter(t -> t.from.equals(address))
                .mapToInt(t -> t.amount).sum();

        int sumIn = this.blocks.stream()
                .flatMap(b -> b.transactionList.stream())
                .filter(t -> t.to.equals(address))
                .mapToInt(t -> t.amount).sum();

        return sumIn - sumOut;
    }

    /**
     * List blocks by total transaction volume - i.e. ignoring to/from (sum of amount).
     * Sorted by highest volume first.
     * The string returned should be formatted as Block #x where x is the index of the block in the chain
     *
     * @param limit how many entries to return
     * @return formatted list of blocks with the highest volume
     */
    public List<String> calculateTopTransactionVolume(int limit) {
        Map<Integer, Integer> map = IntStream.range(0, blocks.size())
                .boxed()
                .collect(Collectors.toMap(Function.identity(), index -> blocks.get(index).transactionList
                        .stream()
                        .mapToInt(t -> t.amount)
                        .sum())
                );
        return map.entrySet().stream()
                .sorted(Comparator.comparingInt((Map.Entry<Integer, Integer> entry) -> entry.getValue()).reversed())
                .map(es -> "Block #" + es.getKey() + " = " + es.getValue())
                .limit(limit)
                .collect(Collectors.toList());
    }

    public long uniqueAddresses() {
        return this.blocks.stream()
                .flatMap(t -> t.transactionList.stream())
                .flatMap(t -> Stream.of(t.from, t.to))
                .distinct()
                .count();
    }

    public String calculateMostValuableAddress() {
        Map<String, Integer> collect = this.blocks.stream()
                .flatMap(t -> t.transactionList.stream())
                .flatMap(t -> Stream.of(t.from, t.to))
                .distinct()
                .collect(Collectors.toMap(s -> s, this::calculateBalance));

        return collect.entrySet().stream().max(Comparator.comparingInt(Map.Entry::getValue))
                .get()
                .getKey();
    }

    /**
     * Calculate average tx. amount for blocks with difficulty >= 2
     *
     * @return The average transaction amount
     */
    public double calculateAverageTxAmount(int minDifficultyLevel) {
        return this.blocks.stream()
                .filter(b -> b.difficulty >= minDifficultyLevel)
                .flatMap(t -> t.transactionList.stream())
                .collect(Collectors.averagingLong(t -> t.amount));
    }

    /**
     * 1. The {@link Block#prevHash} of each block must be the same as the {@link Block#hash}of the previous block in
     * the chain - except the first (genesis) block (it has no previous block).
     * 2. The hash field of every transaction must be verified - it must be equal to the value returned by the
     * {@link Transaction#calculateHash()} method.
     *
     * @return true if the blockchain is considered valid, otherwise false
     */
    public boolean verify() {
        for (int i = 1; i < blocks.size(); i++) {
            Block block = blocks.get(i);
            Block prevBlock = blocks.get(i -1);
            if (!Objects.equals(block.prevHash, prevBlock.hash))
                return false;
            List<Transaction> transactionList = block.transactionList;
            for (Transaction transaction : transactionList) {
                if (!Objects.equals(transaction.hash, transaction.calculateHash()))
                    return false;
            }
        }
        return true;
    }
}
